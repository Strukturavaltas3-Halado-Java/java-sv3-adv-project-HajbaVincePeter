package com.example.restpost.dtos.address_commands;

import com.example.restpost.validator.ValidatePostalAddress;


public interface UpdateCommand {


}
