package com.example.restpost;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestpostApplicationTests {

    @Test
    void contextLoads() {
    }

}
