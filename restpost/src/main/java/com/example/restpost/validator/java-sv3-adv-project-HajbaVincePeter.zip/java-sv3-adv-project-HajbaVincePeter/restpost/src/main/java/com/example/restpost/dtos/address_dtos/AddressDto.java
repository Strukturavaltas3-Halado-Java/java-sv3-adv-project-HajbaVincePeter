package com.example.restpost.dtos.address_dtos;

import com.example.restpost.model.address.Country;

import lombok.*;
@Data
public class AddressDto {

    private Long id;


}
