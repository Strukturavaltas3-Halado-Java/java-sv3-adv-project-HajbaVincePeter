package com.example.restpost.dtos.shipment_commands;

import lombok.NoArgsConstructor;

@NoArgsConstructor
public class CreateEmptyCommand {
}
