delete from shipments;
delete from packages;
delete from addresses;
delete from irish_addresses;
delete from postal_code_addresses;

